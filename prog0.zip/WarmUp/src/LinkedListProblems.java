/*
 * @author: Caden Kienitz
 * Date: 9/13/22
 * CS2321 Warmup
 * Description: This class uses a method to remove duplicate nodes from a singly linked last.
 */
public class LinkedListProblems {

	/*
	 * Given a sorted (SORTED!!!) linked list, delete all duplicates, keep the first
	 * appearance for each element only and return how many non duplicate numbers in
	 * the list
	 * 
	 * Example 1: Input: 1->1->2 Output: 1->2 return 2
	 * 
	 * Example 2: Input: 1->1->2->3->3->3 Output: 1->2->3 return: 3
	 */

	public static int deleteDuplicates(ListNode head) {
		int count = 0;      //counter to keep track of duplicates
		ListNode current = head;
		
		while(current.next != null) {
			if(current.val == current.next.val) {
				current.next = current.next.next;
			}
			else {
				current = current.next;
			}
		}
		
		
		current = head;
		while(current != null) {         // Loops through list to count amount of elements.
			count++;
			current = current.next;
		}
		return count;
	}

}
