
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

/*
 * @author: Caden Kienitz
 * Date: 9/13/22
 * CS2321 Warmup
 */
public class ArrayProblemsTest {

	@Before
	public void setUp() throws Exception {
	}

	/*
	 * sortArray CASE 1: Input: [5,2,4,3,1] Expected Output: the array stays as
	 * [5,2,4,3,1], return 5
	 */
	@Test
	public void testDeleteDuplicatesArray1() {
		int[] nums = { 5, 2, 4, 3, 1 };
		int[] expected = { 5, 2, 4, 3, 1 };
		int n = ArrayProblems.deleteDuplicates(nums);
		assertEquals(5, n);
		assertArrayEquals(expected, nums);
	}

	/*
	 * sortArray CASE 2: Input: [5,1,5,2,0,1,5,1] Expected Output: [5,1,2,0, ....],
	 * returns 4
	 */
	@Test
	public void testDeleteDuplicatesArray2() {

		int[] nums = { 5, 1, 5, 2, 0, 1, 5, 1 };
		int[] expected = { 5, 1, 2, 0 };
		int n = ArrayProblems.deleteDuplicates(nums);
		assertEquals(4, n);
		for (int i = 0; i < n; i++) {
			assertEquals(expected[i], nums[i]);
		}
	}

	/*
	 * sortArray CASE 3: no duplicates Input: [1,1,2,2,1,1,2,2,3,3,3,1,2,3,4,5,4,5]
	 * Expected Output: [1,2,3,4,5, .... ] and return 5
	 */
	@Test
	public void testDeleteDuplicatesArray3() {
		int[] nums = { 1,1,2,2,1,1,2,2,3,3,3,1,2,3,4,5,4,5 };
		int[] expected = {1,2,3,4,5};
		int n = ArrayProblems.deleteDuplicates(nums);
		assertEquals(5, n);
		for (int i = 0; i < n; i++) {
			assertEquals(expected[i], nums[i]);
		}
	}

	/*
	 * sortArray CASE 4: all duplicates Input: [1,1,1,1,1,] Expected Output: [1,...]
	 * and return 1
	 */
	@Test
	public void testDeleteDuplicatesArray4() {
		int[] nums = {1,1,1,1,1};
		int[] expected = {1};
		int n = ArrayProblems.deleteDuplicates(nums);
		assertEquals(1, n);
		for (int i = 0; i < n; i++) {
			assertEquals(expected[i], nums[i]);
		}
	}

}
