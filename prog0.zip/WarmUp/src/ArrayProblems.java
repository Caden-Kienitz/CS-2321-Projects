
/*
 * @author: Caden Kienitz
 * Date: 9/13/22
 * CS2321 Warmup
 * Description: This class uses a method to remove duplicate elements from an array.
 */
public class ArrayProblems {

	/*
	 * Given an array of integers, remove all duplicates except the first appearance
	 * of each number and return how many non duplicated numbers.
	 * 
	 * 
	 * Example 1: Input: [5, 2, 5, 3, 1] output: [5, 2, 3, 0, 0] //The last two
	 * numbers could be anything. return: 3
	 * 
	 * 
	 * Example 2: Input array: [5, 1, 5, 1, 2, 1, 9, 4, 9] Array after removing
	 * duplicates: [5, 1, 2, 9, 4, 0, 0, 0, 0] // The last 4 numbers could be
	 * anything.
	 */

	public static int deleteDuplicates(int[] nums) {
		int counter = nums.length;    //counter keeps track of how many duplicates are removed
		for (int i = 0; i < nums.length-1; i++) {
			for(int k = i+1; k < counter; k++) {
				if(nums[i] == nums[k]) {
					counter--;   // decrease counter when duplicate is detected.
					for(int j = k; j < counter; j++) {
						nums[j] = nums[j+1];     
					
					}
					k--;   //Subtract k to reiterate after shifting elements
				}
				
				
			}
			
			
		}
	
		
		return counter;
							
	}
	
}
