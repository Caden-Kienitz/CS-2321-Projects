import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

/*
 * @author: Caden Kienitz
 * Date: 9/13/22
 * CS2321 Warmup
 */
public class LinkedListProblemsTest {

	@Before
	public void setUp() throws Exception {

	}

	/*
	 * Create a sorted singly linked list using the sorted array data return: head
	 * node
	 */
	private ListNode createList(int[] testdata) {

		ListNode head = new ListNode(testdata[0]);
		ListNode tail = head;
		for (int i = 1; i < testdata.length; i++) {
			ListNode tmp = new ListNode(testdata[i]);
			tail.next = tmp;
			tail = tmp;
		}
		return head;
	}

	/*
	 * Given a sorted linked list, delete all duplicates, keep the first appearance
	 * for each element only Case 1: Input: 1->1->2->3->3->null Output:
	 * 1->2->3->null
	 */
	@Test
	public void testDeleteDuplicates1() {

		// Design the test data. For easy representation, we use array to represent the
		// data
		int[] testdata = { 1, 1, 2, 3, 3 };

		// Describe the expected result.
		// Here I use an array of integer, you could also use another list to represent
		// the data.
		int[] expected = { 1, 2, 3 };
		int expectedNum = 3;

		// Create a sorted list using the data
		ListNode head = createList(testdata);

		// call the method that is being tested
		int n = LinkedListProblems.deleteDuplicates(head);

		// Check the size of the list after duplicates removed
		assertEquals(expectedNum, n);

		// Check the list to see if it matched the expected result.
		ListNode p = head;
		int i = 0;
		while (p != null) {
			// check each element in the list is correct
			assertEquals(expected[i], p.val);
			p = p.next;
			i = i + 1;
		}

		// check the total number of matches equal to the size of expected array
		assertEquals(i, expected.length);

		// check there is no extra data in the list
		assertEquals(null, p);
	}

	/*
	 * test case 2: all duplicates Input: 1->1->1->1->1->null Output: 1->null
	 */
	@Test
	public void testDeleteDuplicates2() {
		
				// data to be tested
				int[] testdata = {1,1,1,1,1};

				//The expected output and number of elements expected.
				int[] expected = {1};
				int expectedNum = 1;

				// Create a sorted list using the data
				ListNode head = createList(testdata);

				// call the method that is being tested
				int n = LinkedListProblems.deleteDuplicates(head);

				// Check the size of the list after duplicates removed
				assertEquals(expectedNum, n);

				// Check the list to see if it matched the expected result.
				ListNode p = head;
				int i = 0;
				while (p != null) {
					// check each element in the list is correct
					assertEquals(expected[i], p.val);
					p = p.next;
					i = i + 1;
				}

				// check the total number of matches equal to the size of expected array
				assertEquals(i, expected.length);

				// check there is no extra data in the list
				assertEquals(null, p);
	}

	/*
	 * test case 3: no duplicates Input: 1->2->3->4->5->null Output:
	 * 1->2->3->4->5->null
	 */
	@Test
	public void testDeleteDuplicates3() {
		// data to be tested
		int[] testdata = {1,2,3,4,5};

		//The expected output and number of elements expected.
		int[] expected = {1,2,3,4,5};
		int expectedNum = 5;

		// Create a sorted list using the data
		ListNode head = createList(testdata);

		// call the method that is being tested
		int n = LinkedListProblems.deleteDuplicates(head);

		// Check the size of the list after duplicates removed
		assertEquals(expectedNum, n);

		// Check the list to see if it matched the expected result.
		ListNode p = head;
		int i = 0;
		while (p != null) {
			// check each element in the list is correct
			assertEquals(expected[i], p.val);
			p = p.next;
			i = i + 1;
		}

		// check the total number of matches equal to the size of expected array
		assertEquals(i, expected.length);

		// check there is no extra data in the list
		assertEquals(null, p);
	}
}
