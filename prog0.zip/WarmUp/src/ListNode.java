/* 
 * This is the node class for a singly linked list 
 * */

public class ListNode {
	int val;
	ListNode next;

	public ListNode(int x) {
		val = x;
	}
}
