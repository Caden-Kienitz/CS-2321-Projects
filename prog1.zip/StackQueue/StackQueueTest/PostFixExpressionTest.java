import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import cs2321.PostfixExpression;

/*
 * @author: Caden Kienitz
 * Date: Sept. 21, 2022
 * CS2321 Program1
 * Description: This class tests PostfixExpression.java
 */
public class PostFixExpressionTest {

	@Before
	public void setUp() throws Exception {
	}

	/*
	 * Test multiple integers followed by operators
	 */
	@Test
	public void testEvaluate1() {
		PostfixExpression tester = new PostfixExpression();
		String testData = "5 5 5 7 8 + + + +";
		int result = tester.evaluate(testData);
		int expected = 30;
		assertEquals(expected, result);
	}
	/*
	 * Test multiple integers followed by all different operators
	 */
	@Test
	public void testEvaluate2() {
		PostfixExpression tester = new PostfixExpression();
		String testData = "5 5 5 5 5 - + / *";
		int result = tester.evaluate(testData);
		int expected = 5;
		assertEquals(expected, result);
	}
	
	/*
	 * Test result of 0
	 */
	@Test
	public void testEvaluate3() {
		PostfixExpression tester = new PostfixExpression();
		String testData = "5 5 -";
		int result = tester.evaluate(testData);
		int expected = 0;
		assertEquals(expected, result);
	}

}
