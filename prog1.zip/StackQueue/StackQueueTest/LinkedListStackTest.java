import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import cs2321.LinkedListStack;

public class LinkedListStackTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		for( int i = 0; i <= 5; i++) {
			//push(3);
			
			
		}
		fail("Not yet implemented");
	}

}
