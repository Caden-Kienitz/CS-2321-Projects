import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import cs2321.CircularArrayQueue;

/*
 * @author: Caden Kienitz
 * Date: Sept. 21, 2022
 * CS2321 Program1
 * Description: This class tests CircularArrayQueue.java
 */
public class CircularArrayTest {

	@Before
	public void setUp() throws Exception {
	}
	/*
	 * Test with reverse sorted queue
	 */
	@Test
	public void Queuetest1() {
		CircularArrayQueue<Integer> queue = new CircularArrayQueue(5);
		queue.enqueue(5);
		queue.enqueue(4);
		queue.enqueue(3);
		queue.enqueue(2);
		queue.enqueue(1);
		int[] expected = {5,4,3,2,1};
		int[] actual = new int[5];
		for(int i = 0; i < actual.length; i++) {
			actual[i] = queue.dequeue();
		}
		assertArrayEquals(expected, actual);
		
	}
	/*
	 * Test large queue of the same value
	 */
	@Test
	public void Queuetest2() {
		CircularArrayQueue<Integer> queue = new CircularArrayQueue(10);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		queue.enqueue(1);
		int[] expected = {1,1,1,1,1,1,1,1,1,1};
		int[] actual = new int[10];
		for(int i = 0; i < actual.length; i++) {
			actual[i] = queue.dequeue();
		}
		assertArrayEquals(expected, actual);
		
	}
	/*
	 * Test proper dequeue
	 */
	@Test
	public void Queuetest3() {
		CircularArrayQueue<Integer> queue = new CircularArrayQueue(2);
		queue.enqueue(1);
		queue.enqueue(3);
		queue.dequeue();
		queue.enqueue(3);
		int[] expected = {3,3};
		int[] actual = new int[2];
		for(int i = 0; i < actual.length; i++) {
			actual[i] = queue.dequeue();
		}
		assertArrayEquals(expected, actual);
		
	}
	/*
	 * Test if enqueue throws exception
	 */
	@Test(expected = IllegalStateException.class)
	public void testException() {
		CircularArrayQueue<Integer> queue = new CircularArrayQueue(3);
		queue.enqueue(1);
		queue.enqueue(2);
		queue.enqueue(3);
		queue.enqueue(4);
	}

}
