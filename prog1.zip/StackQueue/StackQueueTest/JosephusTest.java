import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import cs2321.Josephus;

/*
 * @author: Caden Kienitz
 * Date: Sept. 21, 2022
 * CS2321 Program1
 * Description: This class tests Josephus.java
 */
public class JosephusTest {

	@Before
	public void setUp() throws Exception {
	}
	
	/*
	 * Test one person
	 */
	@Test
	public void testOrder1() { 
		Josephus tester = new Josephus();
		String[] testArray = {"Joe"};
		int k = 1;
		String[] expected = {"Joe"};
		String[] actual = tester.order(testArray, k); 
		assertArrayEquals(expected, actual);
	}

	/*
	 * Test with k = 3
	 */
	@Test
	public void testOrder2() { 
		Josephus tester = new Josephus();
		String[] testArray = {"Alice","Bob", "Cindy", "Doug", "Ed", "Fred"};
		int k = 3;
		String[] expected = {"Cindy","Fred","Doug","Bob","Ed","Alice"};
		String[] actual = tester.order(testArray, k); 
		assertArrayEquals(expected, actual);
	}
	
	/*
	 * Test with larger k value
	 */
	@Test
	public void testOrder3() { 
		Josephus tester = new Josephus();
		String[] testArray = {"Alice","Bob", "Cindy", "Doug", "Ed", "Fred"};
		int k = 4;
		String[] expected = {"Doug", "Bob", "Alice", "Cindy", "Fred", "Ed"};
		String[] actual = tester.order(testArray, k); 
		assertArrayEquals(expected, actual);
	}

	/*
	 * Test with k of 1
	 */
	@Test
	public void testOrder4() { 
		Josephus tester = new Josephus();
		String[] testArray = {"Alice","Bob", "Cindy", "Doug", "Ed", "Fred"};
		int k = 1;
		String[] expected = {"Alice","Bob", "Cindy", "Doug", "E", "Fred"};
		String[] actual = tester.order(testArray, k); 
		assertArrayEquals(expected, actual);
	}

}
